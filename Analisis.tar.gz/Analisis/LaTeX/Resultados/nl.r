# No linealidad.
nl = function(name, vars){
    datos = read.table(name, header=T)
    attach(datos)

    for(j in vars){
        #Gráficas.
        img = paste(paste(name, j, sep = "_"), ".png", sep = "")
        png(img)
        par(mfrow=c(1,2))
        plot(eval(parse(text = j)), ofdb, xlab = j)
        boxplot(ofdb~(eval(parse(text = j))), xlab = j)
        dev.off()

        #Correlación de las variables.
        c = cor(eval(parse(text = j)), ofdb)
        cat(name,"=> Correlación: ", "odbf","-",j," = ",c,"\n")

        #Si la relación indica linealidad o no.
        if(-0.9610 < c && c < 0.9610){
            cat("% No puede suponerse relación de linealidad\n")
        }else{
            cat("% Puede suponerse relación de linealidad\n")
       	}
	}	

}

nle = function(name, vars){
    datos = read.table(name, header=T)
    attach(datos)

    cat("## Algoritmo: ",name,"\n")
    for(j in vars){
        cat("aov(ofdb~",j,")\n")
        print(summary(aov(ofdb~(eval(parse(text=j))))))
    }
}

lineal = FALSE;

if(lineal){
    #Imágenes.

    #PSO
    nl("pso",c("i", "c1", "c2", "w", "vmx"))
    #WPSO
    nl("wpso", c("i", "c1", "c2", "w", "vmx", "w1", "w2", "w3"))
    #DE
    nl("de",c("i", "w1", "w2", "w3"))
    #SDE
    nl("sde",c("i", "w1", "w2", "w3", "f", "pc"))
	#Bee
	nl("bee", c("i", "m", "e", "eb", "ob"))
    #GA
    nl("ga",c("i", "tt", "pc", "pm"))
    #Ant
    nl("ant",c("i", "alpha"))

    #CSV
    #PSO
    nl("pso_csv",c("i", "c1", "c2", "w", "vmx"))
    #WPSO
    nl("wpso_csv", c("i", "c1", "c2", "w", "vmx", "w1", "w2", "w3"))
    #DE
    nl("de_csv",c("i", "w1", "w2", "w3"))
    #SDE
    nl("sde_csv",c("i", "w1", "w2", "w3", "f", "pc"))
	#Bee
	nl("bee_csv", c("i", "m", "e", "eb", "ob"))
    #GA
    nl("ga_csv",c("i", "tt", "pc", "pm"))
    #Ant
    nl("ant_csv",c("i", "alpha"))
}else{
    #Imágenes

    #PSO
    nle("pso",c("i", "c1", "c2", "w", "vmx"))
    #WPSO
    nle("wpso", c("i", "c1", "c2", "w", "vmx", "w1", "w2", "w3"))
    #DE
    nle("de",c("i", "w1", "w2", "w3"))
    #SDE
    nle("sde",c("i", "w1", "w2", "w3", "f", "pc"))
	#Bee
	nle("bee", c("i", "m", "e", "eb", "ob"))
    #GA
    nle("ga",c("i", "tt", "pc", "pm"))
    #Ant
    nle("ant",c("i", "alpha"))

    #CSV
    #PSO
    nle("pso_csv",c("i", "c1", "c2", "w", "vmx"))
    #WPSO
    nle("wpso_csv", c("i", "c1", "c2", "w", "vmx", "w1", "w2", "w3"))
    #DE
    nle("de_csv",c("i", "w1", "w2", "w3"))
    #SDE
    nle("sde_csv",c("i", "w1", "w2", "w3", "f", "pc"))
	#Bee
	nle("bee_csv", c("i", "m", "e", "eb", "ob"))
    #GA
    nle("ga_csv",c("i", "tt", "pc", "pm"))
    #Ant
    nle("ant_csv",c("i", "alpha"))
}


